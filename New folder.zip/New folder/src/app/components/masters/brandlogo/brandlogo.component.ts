import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-brandlogo',
  templateUrl: './brandlogo.component.html',
  styleUrls: ['./brandlogo.component.scss']
})
export class BrandlogoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
