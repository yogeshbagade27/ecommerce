import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transacations',
  templateUrl: './transacations.component.html',
  styleUrls: ['./transacations.component.scss']
})
export class TransacationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
