import { Component, OnInit } from '@angular/core';
import { Menu } from '../../services/menu';
import { NavService } from '../../services/nav.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  menuItems!: Menu[];
  fullName!: string;
  userType!: string;

  constructor(public navService : NavService) {

    

   }

  ngOnInit(): void {
   
    this.menuItems = this.navService.MENUITEMS;
    this.fullName = "Lionel Messi";
    this.userType  = "Admin";
  }

  // Click Toggle Menu
  toggleNavActive(item :any)
  {
      item.active = !item.active;
  }

}
